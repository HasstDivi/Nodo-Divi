Unzip this package to your users home directory.

Method 1:  run divid.  copy divi.conf to the ~/.divi folder.  run divid again and it should say divistarted.

If method 1 does not work you will have to build manually...

Method 2:

Run the divi_install.sh file.  Takes a good chunk of time to compile and install itself and dependencies.

divid on command line should start the daemon.

divi-cli getblockchaininfo # shows blockchain info.
divi-cli help # shows all the cli commands