#! /bin/bash
cd ~
PRESENTDIR=$(pwd)
sudo apt-get --no-install-recommends -yq install software-properties-common
sudo add-apt-repository ppa:bitcoin/bitcoin 
sudo apt-get update
sudo apt-get --no-install-recommends -yq install \
locales \
git-core \
curl \
build-essential \
ca-certificates \
ruby \
rsync \
dos2unix \
wget \
libdb4.8-dev \
libdb4.8++-dev \
libboost-all-dev \
libssl-dev \
libevent-dev \
locales \
git-core \
build-essential \
ca-certificates \
autoconf \
automake \
pkg-config \
libtool \
autotools-dev \
bsdmainutils \
ruby \
sudo \
tor \
net-tools
git clone https://github.com/Divicoin/Divi.git
cd ~/Divi/divi
./autogen.sh
./configure --without-gui
make
sudo make install
mkdir ~/.divi
cp ~/divi.conf ~/.divi/divi.conf
cd $PRESENTDIR
